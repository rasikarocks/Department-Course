package com.tka.StudCrud;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StudCrudApplication {

	public static void main(String[] args) {
		SpringApplication.run(StudCrudApplication.class, args);
	}

}
