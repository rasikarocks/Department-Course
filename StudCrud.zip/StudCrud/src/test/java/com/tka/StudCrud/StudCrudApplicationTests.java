package com.tka.StudCrud;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudCrudApplicationTests {

	@Test
	void contextLoads() {
	}

}
