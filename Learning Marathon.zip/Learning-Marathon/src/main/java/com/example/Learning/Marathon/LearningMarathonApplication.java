package com.example.Learning.Marathon;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LearningMarathonApplication {

	public static void main(String[] args) {
		SpringApplication.run(LearningMarathonApplication.class, args);
	}

}
