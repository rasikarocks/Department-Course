package com.example.Learning.Marathon;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LearningMarathonApplicationTests {

	@Test
	void contextLoads() {
	}

}
