package com.tka.config;

import org.springframework.context.annotation.Configuration;

@Configuration
public class Config {
	/*
	 * @Bean public StudentService getObject() { StudentService ss = new
	 * StudentService(); return ss; }
	 */
}
