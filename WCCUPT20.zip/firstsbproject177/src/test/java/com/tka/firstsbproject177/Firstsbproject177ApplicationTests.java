package com.tka.firstsbproject177;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Firstsbproject177ApplicationTests {

	@Test
	void contextLoads() {
	}

}
